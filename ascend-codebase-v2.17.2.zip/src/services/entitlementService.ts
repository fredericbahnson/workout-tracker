/**
 * Entitlement Service
 *
 * Coordinates trial status and purchase status to determine feature access.
 * This is the web/PWA implementation - when running on iOS via Capacitor,
 * the IAP service will provide purchase information.
 *
 * Access Logic:
 * 1. If user has Advanced purchase → Advanced access
 * 2. If user has Standard purchase → Standard access
 * 3. If trial is active → Advanced access (full features during trial)
 * 4. If trial expired and no purchase → No access (show paywall)
 *
 * On web (PWA), we don't have IAP, so:
 * - Trial functions normally
 * - After trial, users are prompted to use the iOS app for purchase
 * - OR we can give web users full access (business decision)
 */

import { Capacitor } from '@capacitor/core';
import type {
  EntitlementStatus,
  PurchaseInfo,
  PurchaseTier,
  LockedFeatureInfo,
  LockReason,
} from '@/types/entitlement';
import { trialService } from './trialService';
import { iapService } from './iapService';

/**
 * Check if running on a native platform (iOS/Android via Capacitor).
 */
function isNativePlatform(): boolean {
  return Capacitor.isNativePlatform();
}

/**
 * Get purchase info from IAP service.
 * Returns null on web platform.
 */
async function getPurchaseInfo(): Promise<PurchaseInfo | null> {
  if (!isNativePlatform()) return null;
  return iapService.getPurchaseInfo();
}

/**
 * Entitlement Service singleton.
 */
export const entitlementService = {
  /**
   * Initialize entitlement tracking.
   * Call once at app startup.
   */
  async initialize(): Promise<EntitlementStatus> {
    // Initialize IAP service on native platforms
    if (isNativePlatform()) {
      await iapService.initialize();
    }

    // Start trial if this is first launch
    trialService.startTrialIfNeeded();

    // Get current status
    return this.getEntitlementStatus();
  },

  /**
   * Get complete entitlement status.
   */
  async getEntitlementStatus(): Promise<EntitlementStatus> {
    const trial = trialService.getTrialStatus();
    const purchase = await getPurchaseInfo();
    const native = isNativePlatform();

    // Determine effective access level
    let effectiveLevel: PurchaseTier = 'none';

    if (purchase) {
      // Check if subscription is still valid
      const isValid = !purchase.expiresAt || purchase.expiresAt > new Date();
      if (isValid) {
        effectiveLevel = purchase.tier;
      }
    }

    // If no valid purchase but trial is active, give full access
    if (effectiveLevel === 'none' && trial.isActive) {
      effectiveLevel = 'advanced';
    }

    // On web (non-native), we might want to give full access
    // This is a business decision - for now, enforce trial on web too
    // Uncomment below to give web users full access:
    // if (!native) {
    //   effectiveLevel = 'advanced';
    // }

    return {
      trial,
      purchase,
      effectiveLevel,
      canAccessStandard: effectiveLevel !== 'none',
      canAccessAdvanced: effectiveLevel === 'advanced',
      isNativePlatform: native,
      isLoading: false,
    };
  },

  /**
   * Check if a specific feature tier is accessible.
   */
  async checkAccess(requiredTier: PurchaseTier): Promise<LockedFeatureInfo> {
    const status = await this.getEntitlementStatus();

    // 'none' tier is always accessible (shouldn't really be used)
    if (requiredTier === 'none') {
      return { isLocked: false, reason: null, requiredTier };
    }

    // Check Standard access
    if (requiredTier === 'standard') {
      if (status.canAccessStandard) {
        return { isLocked: false, reason: null, requiredTier };
      }
      // Locked - determine reason
      const reason: LockReason = status.trial.hasExpired ? 'trial_expired' : 'not_purchased';
      return { isLocked: true, reason, requiredTier };
    }

    // Check Advanced access
    if (requiredTier === 'advanced') {
      if (status.canAccessAdvanced) {
        return { isLocked: false, reason: null, requiredTier };
      }
      // Locked - determine reason
      let reason: LockReason;
      if (status.purchase?.tier === 'standard') {
        reason = 'standard_only';
      } else if (status.trial.hasExpired) {
        reason = 'trial_expired';
      } else {
        reason = 'not_purchased';
      }
      return { isLocked: true, reason, requiredTier };
    }

    // Unknown tier - treat as locked
    return { isLocked: true, reason: 'not_purchased', requiredTier };
  },

  /**
   * Check if Advanced features are locked.
   * Convenience method for the common case.
   */
  async isAdvancedLocked(): Promise<boolean> {
    const status = await this.getEntitlementStatus();
    return !status.canAccessAdvanced;
  },

  /**
   * Get a user-friendly message for why a feature is locked.
   */
  getLockMessage(reason: LockReason): string {
    switch (reason) {
      case 'trial_expired':
        return 'Your free trial has ended. Subscribe or purchase to continue using this feature.';
      case 'standard_only':
        return 'This feature requires Advanced. Upgrade your subscription to unlock it.';
      case 'not_purchased':
        return 'Start your free trial or subscribe to access this feature.';
      default:
        return 'This feature requires a subscription.';
    }
  },

  /**
   * Get the upgrade CTA text based on lock reason.
   */
  getUpgradeCtaText(reason: LockReason): string {
    switch (reason) {
      case 'trial_expired':
        return 'View Plans';
      case 'standard_only':
        return 'Upgrade to Advanced';
      case 'not_purchased':
        return 'Start Free Trial';
      default:
        return 'View Plans';
    }
  },
};
